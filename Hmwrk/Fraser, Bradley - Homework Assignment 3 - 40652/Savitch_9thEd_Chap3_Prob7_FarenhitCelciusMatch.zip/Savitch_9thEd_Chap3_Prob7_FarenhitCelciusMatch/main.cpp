/* 
 * File:   main.cpp
 * Author: Bradley Fraser
 * Created on January 17, 2018, 6:37 PM
 * Purpose:  Create a program that finds the point where Farenheit and Celcius match.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    int Celcius = 1;
    int Farenheit;
    cout << "Calculating...\n";
    do {
        --Celcius;
        Farenheit = (((Celcius * 9)/5) + 32);
        if (Celcius == Farenheit) {
        cout << "Done.\n" <<  "Celcius = Farenheit at " << Celcius << " degrees.\n";
    }
    } while (Celcius != Farenheit);
    
    return 0;
}